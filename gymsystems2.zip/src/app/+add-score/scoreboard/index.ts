export { ScoreboardComponent } from './scoreboard.component';
export { ScoreGroupComponent } from './score-group.component';
export { ScoreComponent } from './score.component';
