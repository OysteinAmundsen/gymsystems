export { AddScoreComponent } from './add-score.component';
