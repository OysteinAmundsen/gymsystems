export { MacroDialogComponent } from './macro-dialog.component';
