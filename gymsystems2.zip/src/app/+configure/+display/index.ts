export { DisplayComponent } from './display.component';
