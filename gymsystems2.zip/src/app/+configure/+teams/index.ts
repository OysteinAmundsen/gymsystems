export { TeamsComponent } from './teams.component';
