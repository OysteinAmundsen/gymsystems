export { TournamentComponent } from './tournament.component';
