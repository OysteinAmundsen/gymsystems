export { ScoreComponent } from './score.component';
