export { AdvancedComponent } from './advanced.component';
