export { DivisionsComponent } from './divisions.component';
