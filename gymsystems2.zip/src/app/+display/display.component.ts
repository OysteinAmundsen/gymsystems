import { Component, OnInit } from '@angular/core';
import { FaComponent } from '../shared';

@Component({
  moduleId: module.id,
  selector: 'app-display',
  templateUrl: 'display.component.html',
  styleUrls: ['display.component.css']
})
export class DisplayComponent implements OnInit {
  constructor() {}

  ngOnInit() {
  }
}
