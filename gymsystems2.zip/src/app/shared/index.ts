export * from './services/teams.service';
export * from './services/discipline.service';

export { FaComponent } from './fontawesome/fa.component';
export { DialogComponent } from './dialog/dialog.component';
export { FaStackComponent } from './fontawesome/fa-stack.component';

