export { DialogComponent } from './dialog.component';
