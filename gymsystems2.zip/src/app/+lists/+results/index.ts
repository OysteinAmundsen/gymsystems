export { ResultsComponent } from './results.component';
